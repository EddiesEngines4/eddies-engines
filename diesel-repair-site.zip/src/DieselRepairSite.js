import React from "react";
import Logo from "../public/Logo.png";

export default function DieselRepairSite() {
  return (
    <div className="font-sans text-gray-800">
      ...